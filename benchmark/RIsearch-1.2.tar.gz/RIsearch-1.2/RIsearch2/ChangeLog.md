##v 2.1 - 2018-09-07
- Updated mismatched seeds option, NOTE: -m option changed behavior in comparison to previous version
- Added --noGUseed option to disable wobble pairs in the seed
- Added -p3 output option
##v 2.0 - 2017-01-13
- First official release
